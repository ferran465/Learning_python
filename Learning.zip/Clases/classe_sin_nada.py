class programar: 
    pass